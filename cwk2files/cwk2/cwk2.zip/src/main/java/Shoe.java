import java.util.Collections;

public class Shoe extends CardCollection {

  Shoe(int decks) {
    if (decks != 6 && decks != 8) {
      throw new CardException("Shoe is not a value of 6 or 8");
    }

    //iterate through suit values first to get the correct order of suits
    //then another one that repeats this for the number of decks
    //finally iterate thorugh the rank values
    for (Card.Suit s : Card.Suit.values()) {
      for (int i = 0; i < decks; i++) {
        for (Card.Rank r : Card.Rank.values()) {
          BaccaratCard cardshoe = new BaccaratCard(r, s);
          super.add(cardshoe);//add each value to card list
          //card list should be in the correct order
        }
      }
    }

  }

  public int size() {
    return super.size();
  }

  public void shuffle() {
    Collections.shuffle(cards);
  }

  public Card deal() {
    if (cards.size() < 1) {//if card list empty
      throw new CardException("cannot deal from empty shoe");
    }

    Card removed = cards.remove(0);
    return removed;
  }
}
