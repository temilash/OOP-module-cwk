
public class BaccaratHand extends CardCollection {
    public BaccaratHand() {

    }

    @Override
    public int size() {
        return super.size();
    }

    @Override
    public void add(Card card) {
        super.add(card);
    }

    @Override
    public int value() {
        return super.value() % 10;
    }

    public boolean isNatural() {
        //checking if natural by seeing if the hand has two cards and is 8 or 9
        if (size() == 2 && (value() == 8 || value() == 9)) {
            return true;
        }
        return false;
    }

    public String toString() {
        //variable to store string representation
        String handstring = "";

        //getting the string representation fo each card and adding it to string variable
        for (int i = 0; i < cards.size(); i++) {

            if (i == 0) {
                handstring = cards.get(i).toString();
            } else {
                String temp = cards.get(i).toString();
                handstring = handstring + " " + temp;
            }

        }
        return handstring;
    }
}
