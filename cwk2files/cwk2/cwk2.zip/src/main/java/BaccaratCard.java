
public class BaccaratCard extends Card {
  //card class where we just get majority of values from supercalss
  public BaccaratCard(Rank r, Suit s) {
    super(r, s);

  }

  @Override
  public Rank getRank() {
    return super.getRank();
  }

  @Override
  public Suit getSuit() {
    return super.getSuit();

  }

  @Override
  public String toString() {
    return super.toString();

  }

  @Override
  public boolean equals(Object other) {
    return super.equals(other);

  }

  @Override
  public int compareTo(Card other) {
    return super.compareTo(other);

  }

  @Override
  public int value() {
    return super.value() % 10;

  }
}