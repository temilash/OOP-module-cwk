import java.util.Scanner;

public class Baccarat {
  // TODO: Implement your Baccarat simulation program here
  public static void main(String[] args) {

    // creating new instance of shoe class
    Shoe game = new Shoe(6);

    // variables to be used in the game
    boolean end_all = false;
    String conend = "";
    Scanner keyboard = new Scanner(System.in);
    int pwins = 0;
    int bwins = 0;
    int tie = 0;

    game.shuffle();

    // while game is not finished and there is more than 5 cards in the shoe run
    // this while loop
    while (end_all == false && game.size() >= 6) {
      boolean endgame = false;
      // hand instances for banker and player
      BaccaratHand banker = new BaccaratHand();
      BaccaratHand player = new BaccaratHand();

      // print out what round we are on
      System.out.println();
      System.out.println("Round " + (pwins + tie + bwins + 1));
      System.out.println();

      // give out cards
      banker.add(game.deal());
      player.add(game.deal());
      banker.add(game.deal());
      player.add(game.deal());

      // print out the hands
      System.out.println("Player: " + player.toString() + " = " + player.value());
      System.out.println("Banker: " + banker.toString() + " = " + banker.value());

      // if either of them has a natural print they have a natural
      if (player.isNatural()) {
        System.out.println("Player has a natural");
      }
      if (banker.isNatural()) {
        System.out.println("Banker has a natural");
      }

      /*
       * if player and banker are natural they both stand so check for wins
       * set end of round value to true
       * increment the value of banker wins,ties or player wins
       */

      if (player.isNatural() && banker.isNatural()) {
        if (player.value() > banker.value()) {
          System.out.println("Player win!");
          endgame = true;
          pwins += 1;
        } else if (banker.value() > player.value()) {
          System.out.println("Banker win!");
          endgame = true;
          bwins += 1;
        } else if (banker.value() == player.value()) {
          System.out.println("Tie");
          endgame = true;
          tie += 1;
        }
      }
      // if the player value is 9 and banker value is 3 do this
      if (player.value() == 9 && banker.value() == 3 && endgame == false) {

        //draw another card for banker
        banker.add(game.deal());
        System.out.println("Dealing third card to banker");

        System.out.println("Player: " + player.toString() + " = " + player.value());
        System.out.println("Banker: " + banker.toString() + " = " + banker.value());

        if (player.value() > banker.value()) {
          System.out.println("Player win!");
          endgame = true;
          pwins += 1;
        } else if (banker.value() > player.value()) {
          System.out.println("Banker win!");
          endgame = true;
          bwins += 1;
        } else if (banker.value() == player.value()) {
          System.out.println("Tie");
          endgame = true;
          tie += 1;
        }
      }

      //if player has a natural and banker doesnt the player wins
      //already checked for when the player has a natural 9 and when the banker gets a 3
      if (player.isNatural() && banker.isNatural() == false && endgame == false) {
        System.out.println("Player win!");
        endgame = true;
        pwins += 1;
      }

      //if the player gets a value less than 6 draw another card for player
      if (player.value() < 6 && endgame == false) {
        System.out.println("Dealing third card to player");
        player.add(game.deal());
        System.out.println("Player: " + player.toString() + " = " + player.value());
        System.out.println("Banker: " + banker.toString() + " = " + banker.value());

        //check for win
        if (banker.value() >= 7) {
          if (player.value() > banker.value()) {
            System.out.println("Player win!");
            endgame = true;
            pwins += 1;
          } else if (banker.value() > player.value()) {
            System.out.println("Banker win!");
            endgame = true;
            bwins += 1;
          } else if (banker.value() == player.value()) {
            System.out.println("Tie");
            endgame = true;
            tie += 1;
          }
        }

        //conditions for banker drawing another card
        if ((banker.value() <= 2) || (banker.value() == 3 && player.value() != 8)
            || (banker.value() == 4 && player.value() >= 2 && player.value() <= 7)
            || (banker.value() == 5 && player.value() >= 4 && player.value() <= 7)) {

          banker.add(game.deal());
          System.out.println("Dealing third card to banker");

          System.out.println("Player: " + player.toString() + " = " + player.value());
          System.out.println("Banker: " + banker.toString() + " = " + banker.value());

          //check win
          if (player.value() > banker.value()) {
            System.out.println("Player win!");
            endgame = true;
            pwins += 1;
          } else if (banker.value() > player.value()) {
            System.out.println("Banker win!");
            endgame = true;
            bwins += 1;
          } else if (banker.value() == player.value()) {
            System.out.println("Tie");
            endgame = true;
            tie += 1;
          }
        }

      }
      //if value of player was 6 or 7
      if (endgame != true) {
        //check if we need to draw card for banker
        if ((banker.value() <= 2) || (banker.value() == 3 && player.value() != 8)
            || (banker.value() == 4 && player.value() >= 2 && player.value() <= 7)
            || (banker.value() == 5 && player.value() >= 4 && player.value() <= 7)
            || (banker.value() == 6 && player.value() >= 6 && player.value() <= 7)) {

          banker.add(game.deal());
          System.out.println("Dealing third card to banker");

          System.out.println("Player: " + player.toString() + " = " + player.value());
          System.out.println("Banker: " + banker.toString() + " = " + banker.value());

          //check win
          if (player.value() > banker.value()) {
            System.out.println("Player win!");
            endgame = true;
            pwins += 1;
          } else if (banker.value() > player.value()) {
            System.out.println("Banker win!");
            endgame = true;
            bwins += 1;
          } else if (banker.value() == player.value()) {
            System.out.println("Tie");
            endgame = true;
            tie += 1;
          }
        } else {//check win
          if (player.value() > banker.value()) {
            System.out.println("Player win!");
            endgame = true;
            pwins += 1;
          } else if (banker.value() > player.value()) {
            System.out.println("Banker win!");
            endgame = true;
            bwins += 1;
          } else if (banker.value() == player.value()) {
            System.out.println("Tie");
            endgame = true;
            tie += 1;
          }
        }
      }
      System.out.print("Another round? (y/n): ");
      //if in interactive mode allow player to choose whether to continue or stop
      if (keyboard.hasNextLine()) {
        conend = (keyboard.nextLine()).toLowerCase();
        System.out.println();
        if (conend.equals("y")) {
          end_all = false;
        } else {
          end_all = true;
        }
      }
      System.out.println();
    }
    //printing out the values of rounds,wins,ties
    System.out.println();
    System.out.println((bwins + tie + pwins) + " rounds played");
    System.out.println(pwins + " player wins");
    System.out.println(bwins + " banker wins");
    System.out.println(tie + " ties");

  }

}
